import React from 'react'

export default function Shop() {
    return (
        <div>
        <h1>This is Shop's Page</h1>
            
        </div>
    )
}

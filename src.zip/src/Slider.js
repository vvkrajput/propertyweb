

import React from 'react'

export default function Slider() {
    return (
        <div>
        <input type="range" min="1" max="100" value="50" class="slider-square" id="id2"></input>



            
        </div>
    )
}

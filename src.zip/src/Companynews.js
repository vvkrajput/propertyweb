import React from 'react'

export default function Companynews() {
    return (
        <div>
            <h1>Company News Page</h1>
        </div>
    )
}

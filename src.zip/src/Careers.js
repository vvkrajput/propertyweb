import React from 'react'

export default function Careers() {
    return (
        <div>
            <h1>Carrers Page</h1>
        </div>
    )
}

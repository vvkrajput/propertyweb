import React from 'react'

export default function () {
    return (
        <div>
            <h1> Plot's Page</h1>
        </div>
    )
}

import React from 'react'

export default function house() {
    return (
        <div>
           <h1>Independent House Page</h1>
        </div>
    )
}

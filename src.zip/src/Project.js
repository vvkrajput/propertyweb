import React from 'react'

export default function Project() {
    return (
        <div>
            <h1>Project's Page</h1>
        </div>
    )
}

import React from 'react'
 function flat() {
    return (
        <div>
            <h1>  
            This is Flat's page          

            </h1>
            
        </div>
    )
}
export default flat;
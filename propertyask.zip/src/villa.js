import React from 'react'

 function villa() {
    return (
        <div>
           <h1>     
               Villa's Page
               

           </h1>
            
        </div>
    )
}
export default villa

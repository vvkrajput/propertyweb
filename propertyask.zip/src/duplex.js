import React from 'react'

export default function duplex() {
    return (
        <div>
            <h1>
                This is Duplex's page
            </h1>
        </div>
    )
}

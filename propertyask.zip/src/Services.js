import React from 'react'

export default function Services() {
    return (
        <div>
            <h1> This is Property Ask's Service Page</h1>
        </div>
    )
}

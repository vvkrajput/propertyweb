import React, { Component } from 'react'
import {Row,Col } from 'react-bootstrap';
import Ownericon from './images/ownericon.png';

export class ownerdetails extends Component {
    render() {
        return (
            <div className="text img-thumbnail thumbnailnext" id="ca9c4a">

            

            <h4>Himanshu</h4>
             <h6>Owner</h6>
             <div className="interestedformownerdetails">
              <h6>+9123XXX345678</h6>
            
             <button className="propertydetailsbutton">Click to view Number</button>
             </div>
            
             
             


                
            </div>

        )
    }
}

export default ownerdetails

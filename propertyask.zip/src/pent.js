import React from 'react'

export default function pent() {
    return (
        <div>
            <h1>This is Pent House Page</h1>
        </div>
    )
}
